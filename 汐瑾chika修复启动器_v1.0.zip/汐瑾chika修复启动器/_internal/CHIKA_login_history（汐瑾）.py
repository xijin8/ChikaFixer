"""Compiled module loader (no readable source in this distribution)."""
import marshal as _marshal
from pathlib import Path as _path

with _path(__file__ + ".bin").open("rb") as _stream:
    _code = _marshal.loads(_stream.read())

exec(_code, globals())
del _code, _stream
